#!/usr/bin/env python3
"""
ROS2 Jazzy node that uses a custom YOLOv5n model (label: 'box') + known
physical size (e.g. Korea Post Box No.4: 0.41 x 0.31 x 0.28 m) to detect
only boxes whose 3D size matches the target within a configurable tolerance.

요약:
- YOLOv5n 모델에서 'box' 라벨만 사용
- RGB + Depth 이미지와 카메라 내파라미터를 이용해 3D 크기 추정
- (0.41, 0.31, 0.28)m 와의 차이가 허용 오차(기본 0.05m = 5cm) 이내인 경우만
  "실제 4호 상자" 로 판단
- 해당 박스 중심을 camera_link 기준 PoseStamped 로 publish

필수 전제:
- ROS2 Jazzy
- rclpy, cv_bridge, sensor_msgs, geometry_msgs 설치 (apt)
- YOLOv5n 커스텀 모델 (weights) 파일 준비
- Depth 이미지와 RGB 이미지가 대략 동기 (또는 정확히 동기) 되어 있음
- 카메라 내파라미터(fx, fy, cx, cy)를 파라미터로 제공

실행 예시 (단독 실행):

  python box_detector_with_size_yolov5.py \
    --ros-args \
      -p model_path:=/path/to/box_yolov5n.pt \
      -p rgb_topic:=/camera/color/image_raw \
      -p depth_topic:=/camera/aligned_depth_to_color/image_raw \
      -p fx:=615.0 -p fy:=615.0 -p cx:=320.0 -p cy:=240.0 \
      -p length_tolerance_m:=0.05

출력:
- /box_detector/box_pose (geometry_msgs/PoseStamped, frame_id = rgb frame)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
import cv2
import torch

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import PoseStamped
from cv_bridge import CvBridge, CvBridgeError


# Target physical size of the box (e.g. Korea Post Box No.4)
TARGET_DIMENSIONS_M = (0.41, 0.31, 0.28)  # (L, W, H) meters

# Global default tolerance (can be overridden by ROS2 param length_tolerance_m)
DEFAULT_LENGTH_TOLERANCE_M = 0.05  # 5 cm


@dataclass
class CameraIntrinsics:
    fx: float
    fy: float
    cx: float
    cy: float


class BoxDetectorWithSizeNode(Node):
    """
    ROS2 node:
    - subscribes to RGB + depth
    - runs YOLOv5n (label: 'box')
    - for each 'box' detection, estimates 3D size using depth
    - accepts only detections whose 3D dimensions match TARGET_DIMENSIONS_M
      within length_tolerance_m
    - publishes PoseStamped of the box center in camera frame
    """

    def __init__(self) -> None:
        super().__init__("box_detector_with_size_yolov5")

        # Parameters
        self.declare_parameter("model_path", "/path/to/box_yolov5n.pt")
        self.declare_parameter("rgb_topic", "/camera/color/image_raw")
        self.declare_parameter("depth_topic", "/camera/aligned_depth_to_color/image_raw")
        self.declare_parameter("conf_threshold", 0.4)
        self.declare_parameter("length_tolerance_m", DEFAULT_LENGTH_TOLERANCE_M)

        # Camera intrinsics
        self.declare_parameter("fx", 615.0)
        self.declare_parameter("fy", 615.0)
        self.declare_parameter("cx", 320.0)
        self.declare_parameter("cy", 240.0)

        model_path = (
            self.get_parameter("model_path").get_parameter_value().string_value
        )
        rgb_topic = (
            self.get_parameter("rgb_topic").get_parameter_value().string_value
        )
        depth_topic = (
            self.get_parameter("depth_topic").get_parameter_value().string_value
        )
        self.conf_threshold = (
            self.get_parameter("conf_threshold").get_parameter_value().double_value
        )
        self.length_tolerance_m = (
            self.get_parameter("length_tolerance_m")
            .get_parameter_value()
            .double_value
        )

        fx = self.get_parameter("fx").get_parameter_value().double_value
        fy = self.get_parameter("fy").get_parameter_value().double_value
        cx = self.get_parameter("cx").get_parameter_value().double_value
        cy = self.get_parameter("cy").get_parameter_value().double_value
        self.intrinsics = CameraIntrinsics(fx=fx, fy=fy, cx=cx, cy=cy)

        self.get_logger().info(f"Loading YOLOv5 model from: {model_path}")
        # NOTE: this assumes torch hub local cache or internet access on first run.
        # For offline use, clone the yolov5 repo and adjust the 'source' argument.
        self.model = torch.hub.load(
            "ultralytics/yolov5",
            "custom",
            path=model_path,
            source="github",  # change to 'local' if using a local repo
        )
        self.model.eval()

        self.bridge = CvBridge()

        # Latest depth image cache
        self.latest_depth: Optional[np.ndarray] = None
        self.latest_depth_stamp = None
        self.latest_depth_frame_id: Optional[str] = None

        # Subscribers
        self.rgb_sub = self.create_subscription(
            Image,
            rgb_topic,
            self.rgb_callback,
            10,
        )
        self.depth_sub = self.create_subscription(
            Image,
            depth_topic,
            self.depth_callback,
            10,
        )

        # Publisher: box center pose in camera frame
        self.pose_pub = self.create_publisher(
            PoseStamped,
            "/box_detector/box_pose",
            10,
        )

        self.get_logger().info(
            "BoxDetectorWithSizeNode initialized:\n"
            f"  model_path={model_path}\n"
            f"  rgb_topic={rgb_topic}\n"
            f"  depth_topic={depth_topic}\n"
            f"  conf_threshold={self.conf_threshold}\n"
            f"  length_tolerance_m={self.length_tolerance_m}\n"
            f"  intrinsics={self.intrinsics}"
        )

    # -------------------------------------------------------------------------
    # Callbacks
    # -------------------------------------------------------------------------

    def depth_callback(self, msg: Image) -> None:
        """Cache the latest depth image."""
        try:
            # Try 32FC1 first
            depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding="32FC1")
        except CvBridgeError:
            try:
                # Fallback: 16UC1 (e.g. depth in millimeters)
                depth_raw = self.bridge.imgmsg_to_cv2(msg, desired_encoding="16UC1")
                depth = depth_raw.astype(np.float32) / 1000.0  # mm -> m
            except CvBridgeError as e:
                self.get_logger().error(f"Depth cv_bridge error: {e}")
                return

        self.latest_depth = depth
        self.latest_depth_stamp = msg.header.stamp
        self.latest_depth_frame_id = msg.header.frame_id

    def rgb_callback(self, msg: Image) -> None:
        """Run YOLOv5 on RGB image and filter detections by 3D size."""
        if self.latest_depth is None:
            # No depth yet
            return

        try:
            rgb = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except CvBridgeError as e:
            self.get_logger().error(f"RGB cv_bridge error: {e}")
            return

        # YOLOv5 inference expects BGR or RGB np.ndarray; here we use BGR as is.
        results = self.model(rgb)
        # results.xyxy[0]: [x1, y1, x2, y2, conf, cls]
        boxes = results.xyxy[0]
        names = results.names

        if boxes is None or len(boxes) == 0:
            return

        # Iterate detections
        for det in boxes:
            x1, y1, x2, y2, conf, cls_id = det.tolist()
            conf = float(conf)
            cls_id = int(cls_id)
            class_name = names.get(cls_id, str(cls_id))

            # Filter by label 'box' and confidence
            if class_name != "box":
                continue
            if conf < self.conf_threshold:
                continue

            bbox = (int(x1), int(y1), int(x2), int(y2))
            dims, center_cam = self.estimate_3d_size_and_center(
                bbox, self.latest_depth, self.intrinsics
            )
            if dims is None or center_cam is None:
                continue

            if self.is_size_match(dims, TARGET_DIMENSIONS_M, self.length_tolerance_m):
                # Valid box candidate: publish its 3D center as PoseStamped
                pose_msg = PoseStamped()
                pose_msg.header.stamp = msg.header.stamp
                # frame id: we use RGB frame; adjust if you prefer depth frame
                pose_msg.header.frame_id = msg.header.frame_id

                pose_msg.pose.position.x = float(center_cam[0])
                pose_msg.pose.position.y = float(center_cam[1])
                pose_msg.pose.position.z = float(center_cam[2])
                # No orientation estimation; identity quaternion
                pose_msg.pose.orientation.x = 0.0
                pose_msg.pose.orientation.y = 0.0
                pose_msg.pose.orientation.z = 0.0
                pose_msg.pose.orientation.w = 1.0

                self.pose_pub.publish(pose_msg)

                self.get_logger().info(
                    "Detected box (size matched): "
                    f"class='box', conf={conf:.3f}, "
                    f"dims(m)={dims}, "
                    f"center_cam(m)={center_cam}"
                )
            else:
                self.get_logger().debug(
                    "Rejected box (size mismatch): "
                    f"class='box', conf={conf:.3f}, dims(m)={dims}"
                )

    # -------------------------------------------------------------------------
    # Size estimation and matching
    # -------------------------------------------------------------------------

    @staticmethod
    def estimate_3d_size_and_center(
        bbox: Tuple[int, int, int, int],
        depth: np.ndarray,
        intrinsics: CameraIntrinsics,
        sample_grid: int = 5,
    ) -> Tuple[Optional[Tuple[float, float, float]], Optional[Tuple[float, float, float]]]:
        """
        Estimate 3D bounding box dimensions (dx, dy, dz) and center (cx, cy, cz)
        for a detection using depth image and camera intrinsics.

        - bbox: (x1, y1, x2, y2) in pixel coordinates
        - depth: 2D array (meters)
        - sample_grid: number of samples along each axis inside the bbox
        """
        x1, y1, x2, y2 = bbox
        h, w = depth.shape[:2]

        x1 = max(0, min(w - 1, x1))
        x2 = max(0, min(w - 1, x2))
        y1 = max(0, min(h - 1, y1))
        y2 = max(0, min(h - 1, y2))

        if x2 <= x1 or y2 <= y1:
            return None, None

        xs = np.linspace(x1, x2, num=sample_grid, dtype=np.int32)
        ys = np.linspace(y1, y2, num=sample_grid, dtype=np.int32)

        points_3d: List[np.ndarray] = []
        for u in xs:
            for v in ys:
                z = float(depth[v, u])
                if z <= 0.0 or not np.isfinite(z):
                    continue
                X = (u - intrinsics.cx) * z / intrinsics.fx
                Y = (v - intrinsics.cy) * z / intrinsics.fy
                Z = z
                points_3d.append(np.array([X, Y, Z], dtype=np.float32))

        if len(points_3d) < 3:
            # Not enough valid depth points to estimate size
            return None, None

        pts = np.stack(points_3d, axis=0)
        min_xyz = pts.min(axis=0)
        max_xyz = pts.max(axis=0)
        dims = max_xyz - min_xyz  # (dx, dy, dz)
        center = (min_xyz + max_xyz) / 2.0

        return (
            (float(dims[0]), float(dims[1]), float(dims[2])),
            (float(center[0]), float(center[1]), float(center[2])),
        )

    @staticmethod
    def is_size_match(
        measured_dims: Tuple[float, float, float],
        target_dims: Tuple[float, float, float],
        tolerance_m: float,
    ) -> bool:
        """
        Compare measured (dx, dy, dz) with target (L, W, H) ignoring axis order.
        Both tuples are sorted before comparison and must be within tolerance_m.

        measured_dims: (dx, dy, dz)
        target_dims: (L, W, H)
        """
        m_sorted = sorted(measured_dims)
        t_sorted = sorted(target_dims)

        for m, t in zip(m_sorted, t_sorted):
            if abs(m - t) > tolerance_m:
                return False
        return True


def main(args: Optional[List[str]] = None) -> None:
    rclpy.init(args=args)
    node = BoxDetectorWithSizeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down BoxDetectorWithSizeNode (KeyboardInterrupt).")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()